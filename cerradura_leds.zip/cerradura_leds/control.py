"""Secuencias de los LED. No depende de la cámara ni del reconocimiento."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Luces:
    verde: bool
    rojo: bool
    amarillo: bool


class Control:
    def __init__(self, config):
        self.c = config
        self.estado = "CERRADA"
        self.desde = 0.0
        self.armado = True
        self.ausente_desde = None
        self.ultimo = None
        self.candidato = None
        self.inicio_candidato = 0.0
        self.lecturas = 0
        self.detalle = "Esperando un rostro"

    def limpiar_candidato(self):
        self.candidato = None
        self.lecturas = 0

    def activar(self, autorizado, ahora, nombre="Prueba manual"):
        self.estado = "ABIERTA" if autorizado else "DENEGADO"
        self.detalle = ("Autorizado: " + nombre) if autorizado else "Acceso denegado"
        self.desde = ahora
        self.armado = False
        self.ausente_desde = None
        self.limpiar_candidato()

    def fallo(self, ahora):
        self.estado = "FALLO"
        self.desde = ahora
        self.detalle = "Sin imagen reciente. Comprueba la cámara"
        self.armado = False
        self.ausente_desde = None
        self.ultimo = None
        self.limpiar_candidato()

    def observar(self, identidad, ahora):
        """None: vacío; '?': desconocido; '*': varios; '~': muy lejos."""
        if self.estado == "FALLO":
            self.estado = "CERRADA"
        if self.ultimo is not None and ahora - self.ultimo > 1.0:
            self.limpiar_candidato()
            self.ausente_desde = None
        self.ultimo = ahora
        self.actualizar(ahora)
        if identidad is None:
            self.limpiar_candidato()
            if self.ausente_desde is None:
                self.ausente_desde = ahora
            if (self.estado == "CERRADA" and
                    ahora - self.ausente_desde >= self.c["segundos_sin_rostro"]):
                self.armado = True
            if self.estado == "CERRADA":
                self.detalle = "Esperando un rostro" if self.armado else "Retírate dos segundos"
            return
        self.ausente_desde = None
        if self.estado != "CERRADA":
            return
        if not self.armado:
            self.detalle = "Retírate del encuadre dos segundos para otro intento"
            return
        if identidad == "~":
            self.limpiar_candidato()
            self.detalle = "Acércate y mira hacia la cámara"
            return
        if identidad != self.candidato:
            self.candidato = identidad
            self.inicio_candidato = ahora
            self.lecturas = 0
        self.lecturas += 1
        self.detalle = "Comprobando rostro..."
        if (self.lecturas >= self.c["lecturas_confirmacion"] and
                ahora - self.inicio_candidato >= self.c["segundos_confirmacion"]):
            self.activar(identidad not in ("?", "*"), ahora, identidad)
            if identidad == "*":
                self.detalle = "Acceso denegado: una persona a la vez"

    def actualizar(self, ahora):
        duracion = {"ABIERTA": self.c["segundos_abierta"],
                    "DENEGADO": self.c["segundos_denegado"]}.get(self.estado)
        if duracion is not None and ahora - self.desde >= duracion:
            self.estado = "CERRADA"
            self.detalle = "Retírate del encuadre dos segundos para otro intento"

    def luces(self, ahora):
        self.actualizar(ahora)
        t = max(0.0, ahora - self.desde)
        if self.estado == "ABIERTA":
            return Luces(True, False, t < 0.2)
        if self.estado == "DENEGADO":
            pulso = int((t + 1e-9) / 0.2) % 2 == 0
            return Luces(False, pulso, t < 1.0 and pulso)
        return Luces(False, True, False)


class Salidas:
    def __init__(self, config, simular=False):
        self.dispositivos = []
        if not simular:
            from gpiozero import LED
            try:
                for pin in (config["gpio_verde"], config["gpio_rojo"],
                            config["gpio_buzzer_simulado"]):
                    self.dispositivos.append(LED(pin, initial_value=False))
            except Exception:
                self.close()
                raise
        self.aplicar(Luces(False, True, False))

    def aplicar(self, luces):
        # Apagar antes de encender evita solapar verde y rojo al cambiar de estado.
        valores = (luces.verde, luces.rojo, luces.amarillo)
        for dispositivo, encendido in zip(self.dispositivos, valores):
            if not encendido:
                dispositivo.off()
        for dispositivo, encendido in zip(self.dispositivos, valores):
            if encendido:
                dispositivo.on()

    def close(self):
        for dispositivo in self.dispositivos:
            dispositivo.off()
            dispositivo.close()
        self.dispositivos.clear()
