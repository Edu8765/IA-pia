"""Descarga oficial, una sola vez; comprueba SHA-256 antes de usar los modelos."""
from pathlib import Path
import hashlib
import urllib.request
import cv2

BASE = Path(__file__).resolve().parent
MODELOS = BASE / "modelos"
LEGACY_REV = "91fb0290f50896f38a0ab1e558b74b16bc009428"


def especificaciones():
    completa = tuple(int(x) for x in cv2.__version__.split(".")[:3])
    version = completa[:2]
    if completa < (4, 5, 4) or version >= (5, 0):
        raise RuntimeError("Esta versión del proyecto requiere OpenCV 4.5.4 a 4.x.")
    if version < (4, 8):
        detector = ("face_detection_yunet_2022mar.onnx", "face_detection_yunet",
                    LEGACY_REV, "50ef07f702a31741ca46a4c0d947773b64143b9362780237bf0d427d6c79bab7")
    else:
        detector = ("face_detection_yunet_2023mar.onnx", "face_detection_yunet", "main",
                    "8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4")
    reconocimiento = ("face_recognition_sface_2021dec.onnx", "face_recognition_sface", "main",
                      "0ba9fbfa01b5270c96627c4ef784da859931e02f04419c829e83484087c34e79")
    return detector, reconocimiento


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as archivo:
        for bloque in iter(lambda: archivo.read(1024 * 1024), b""):
            digest.update(bloque)
    return digest.hexdigest()


def descargar():
    MODELOS.mkdir(exist_ok=True)
    for nombre, carpeta, revision, esperado in especificaciones():
        destino = MODELOS / nombre
        if destino.is_file() and sha256(destino) == esperado:
            print("Modelo verificado:", nombre, flush=True)
            continue
        url = f"https://media.githubusercontent.com/media/opencv/opencv_zoo/{revision}/models/{carpeta}/{nombre}"
        temporal = destino.with_suffix(".part")
        print("Descargando", nombre, "...", flush=True)
        try:
            with urllib.request.urlopen(url, timeout=60) as respuesta, temporal.open("wb") as archivo:
                while True:
                    bloque = respuesta.read(1024 * 1024)
                    if not bloque:
                        break
                    archivo.write(bloque)
            if sha256(temporal) != esperado:
                raise RuntimeError("Descarga incompleta o diferente de la esperada: " + nombre)
            temporal.replace(destino)
        finally:
            temporal.unlink(missing_ok=True)
    print("Modelos listos. El reconocimiento ya puede funcionar sin Internet.")


if __name__ == "__main__":
    descargar()
