"""Pruebas de lógica: python3 -m unittest -v test_control.py (sin GPIO/cámara)."""
import json
from pathlib import Path
import unittest
from control import Control, Luces


class PruebasControl(unittest.TestCase):
    def setUp(self):
        self.config = json.loads(Path(__file__).with_name("config.json").read_text())
        self.control = Control(self.config)

    def confirmar(self, identidad, inicio=0):
        for paso in (0, 0.3, 0.6, 0.9):
            self.control.observar(identidad, inicio + paso)

    def test_reposo_y_sin_rostro_no_deniega(self):
        for t in range(20):
            self.control.observar(None, t)
            self.assertEqual(self.control.luces(t), Luces(False, True, False))

    def test_reconocido_abre_y_vuelve_a_cerrar(self):
        self.confirmar("Eduardo")
        self.assertEqual(self.control.luces(0.9), Luces(True, False, True))
        self.assertEqual(self.control.luces(1.2), Luces(True, False, False))
        self.assertEqual(self.control.luces(6.0), Luces(False, True, False))

    def test_lectura_aislada_no_abre(self):
        self.control.observar("Eduardo", 0)
        self.control.observar(None, 0.3)
        self.confirmar("?", 0.6)
        self.assertEqual(self.control.estado, "DENEGADO")

    def test_mismo_rostro_no_repite(self):
        self.confirmar("Eduardo")
        for paso in range(10, 150):
            self.control.observar("Eduardo", paso / 10)
        self.assertEqual(self.control.estado, "CERRADA")
        self.assertFalse(self.control.armado)

    def test_rearme_exige_ausencia_continua(self):
        self.confirmar("Eduardo")
        for t in (6, 6.5, 7, 7.5, 8.1):
            self.control.observar(None, t)
        self.assertTrue(self.control.armado)
        self.confirmar("Eduardo", 8.2)
        self.assertEqual(self.control.estado, "ABIERTA")

    def test_denegado_tres_pulsos_y_rojo_parpadea(self):
        self.confirmar("?")
        for delta in (0.05, 0.45, 0.85):
            self.assertEqual(self.control.luces(0.9+delta), Luces(False, True, True))
        for delta in (0.25, 0.65, 1.05):
            self.assertEqual(self.control.luces(0.9+delta), Luces(False, False, False))
        self.assertEqual(self.control.luces(3), Luces(False, True, False))

    def test_varias_caras_deniega(self):
        self.confirmar("*")
        self.assertEqual(self.control.estado, "DENEGADO")

    def test_rostro_pequeno_no_decide(self):
        self.confirmar("~")
        self.assertEqual(self.control.estado, "CERRADA")
        self.assertTrue(self.control.armado)

    def test_no_mezcla_personas(self):
        for i, persona in enumerate(["Eduardo", "David"] * 10):
            self.control.observar(persona, i * 0.3)
        self.assertEqual(self.control.estado, "CERRADA")

    def test_fallo_cierra_y_exige_rearmar(self):
        self.confirmar("Eduardo")
        self.control.fallo(1.0)
        self.assertEqual(self.control.luces(1.0), Luces(False, True, False))
        self.confirmar("Eduardo", 1.2)
        self.assertEqual(self.control.estado, "CERRADA")
        self.assertFalse(self.control.armado)

    def test_intervalos_largos_no_acumulan_confirmacion(self):
        for t in (0, 2, 4, 6):
            self.control.observar("Eduardo", t)
        self.assertEqual(self.control.estado, "CERRADA")

    def test_ausencia_interrumpida_no_rearma(self):
        self.confirmar("?")
        self.control.observar(None, 3)
        self.control.observar("?", 3.5)
        self.control.observar(None, 4)
        self.control.observar(None, 4.9)
        self.assertFalse(self.control.armado)


if __name__ == "__main__":
    unittest.main()
