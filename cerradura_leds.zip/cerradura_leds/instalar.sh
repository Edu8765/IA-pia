#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
printf '%s\n' 'Instalación en Raspberry Pi OS (necesita Internet esta primera vez).'
sudo apt update
sudo apt install -y python3-opencv python3-gpiozero python3-tk python3-pil.imagetk
/usr/bin/python3 descargar_modelos.py
printf '%s\n' 'Listo. Dentro de esta carpeta ejecuta: python3 app.py leds'
