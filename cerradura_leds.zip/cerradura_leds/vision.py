"""Cámara y reconocimiento en segundo plano para no detener las secuencias GPIO."""
from dataclasses import dataclass
from pathlib import Path
import json
import threading
import time
import cv2
import numpy as np
from descargar_modelos import MODELOS, especificaciones

BASE = Path(__file__).resolve().parent
BASE_ROSTROS = BASE / "rostros.json"


def normalizar(vector):
    vector = np.asarray(vector, dtype=np.float32).reshape(-1)
    norma = np.linalg.norm(vector)
    if vector.size != 128 or not np.isfinite(vector).all() or norma < 1e-8:
        raise ValueError("Vector facial inválido")
    return vector / norma


def cargar_rostros():
    if not BASE_ROSTROS.exists():
        return {}
    datos = json.loads(BASE_ROSTROS.read_text(encoding="utf-8"))
    if datos.get("version") != 1:
        raise ValueError("Formato de rostros.json no compatible")
    return {nombre: normalizar(vector) for nombre, vector in datos["personas"].items()}


def guardar_persona(nombre, muestras):
    nombre = nombre.strip()
    if not nombre or nombre in ("?", "*", "~") or len(nombre) > 50:
        raise ValueError("Usa un nombre de 1 a 50 caracteres")
    personas = cargar_rostros()
    if nombre in personas:
        raise ValueError("Ese nombre ya está registrado. Usa otro nombre o edita rostros.json.")
    personas[nombre] = normalizar(np.mean(muestras, axis=0))
    datos = {"version": 1, "personas": {n: v.tolist() for n, v in personas.items()}}
    temporal = BASE_ROSTROS.with_suffix(".tmp")
    temporal.write_text(json.dumps(datos, ensure_ascii=False, indent=2), encoding="utf-8")
    temporal.replace(BASE_ROSTROS)


def identificar(vector, personas, umbral, margen):
    if not personas:
        return "?", 0.0
    ranking = sorted(((float(np.dot(vector, referencia)), nombre)
                      for nombre, referencia in personas.items()), reverse=True)
    mejor, nombre = ranking[0]
    separacion = mejor - ranking[1][0] if len(ranking) > 1 else 2.0
    return (nombre if mejor >= umbral and separacion >= margen else "?"), mejor


class MotorRostros:
    def __init__(self, config, personas):
        self.c = config
        self.personas = personas
        detector, reconocedor = (MODELOS / m[0] for m in especificaciones())
        if not detector.is_file() or not reconocedor.is_file():
            raise RuntimeError("Faltan modelos. Ejecuta: python3 descargar_modelos.py")
        cv2.setNumThreads(2)
        self.detector = cv2.FaceDetectorYN.create(str(detector), "", (640, 480), 0.9, 0.3, 5000)
        self.reconocedor = cv2.FaceRecognizerSF.create(str(reconocedor), "")

    def analizar(self, original):
        alto, ancho = original.shape[:2]
        factor = min(640 / ancho, 480 / alto)
        imagen = cv2.resize(original, (round(ancho * factor), round(alto * factor)))
        self.detector.setInputSize((imagen.shape[1], imagen.shape[0]))
        _, caras = self.detector.detect(imagen)
        caras = [] if caras is None else caras
        vector = None
        identidad, detalle = None, "Sin rostro"
        if len(caras) > 1:
            identidad, detalle = "*", "Una persona a la vez"
        elif len(caras) == 1:
            cara = caras[0]
            if min(cara[2], cara[3]) < self.c["tamano_minimo_rostro"]:
                identidad, detalle = "~", "Acercate a la camara"
            else:
                alineado = self.reconocedor.alignCrop(imagen, cara)
                vector = normalizar(self.reconocedor.feature(alineado))
                identidad, puntuacion = identificar(vector, self.personas,
                    self.c["umbral_similitud"], self.c["margen_identidades"])
                detalle = ("Desconocido" if identidad == "?" else identidad)
                if self.personas:
                    detalle += f" | similitud: {puntuacion:.2f}"
                else:
                    detalle = "Rostro listo para registrar"
        for cara in caras:
            x, y, w, h = [int(v) for v in cara[:4]]
            color = (0, 200, 0) if identidad not in (None, "?", "*", "~") else (0, 180, 255)
            cv2.rectangle(imagen, (x, y), (x + w, y + h), color, 2)
        return imagen, identidad, detalle, vector


class Camara:
    def __init__(self, fuente):
        self.fuente = fuente
        self.stop = threading.Event()
        self.lock = threading.Lock()
        self.ultimo = None
        self.secuencia = 0
        self.hilo = threading.Thread(target=self._leer, daemon=True)
        self.hilo.start()

    def _leer(self):
        while not self.stop.is_set():
            cap = None
            try:
                if isinstance(self.fuente, int):
                    cap = cv2.VideoCapture(self.fuente, cv2.CAP_V4L2)
                    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
                    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                    cap.set(cv2.CAP_PROP_FPS, 15)
                    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                else:
                    cap = cv2.VideoCapture(self.fuente, cv2.CAP_FFMPEG, [
                        cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 3000,
                        cv2.CAP_PROP_READ_TIMEOUT_MSEC, 1500])
                while not self.stop.is_set() and cap.isOpened():
                    ok, frame = cap.read()
                    if not ok or frame is None:
                        break
                    with self.lock:
                        self.secuencia += 1
                        self.ultimo = (self.secuencia, time.monotonic(), frame)
            except Exception:
                pass  # El hilo principal detecta la falta de imágenes recientes.
            finally:
                if cap is not None:
                    cap.release()
            self.stop.wait(1.0)

    def obtener(self):
        with self.lock:
            return self.ultimo

    def close(self):
        self.stop.set()
        self.hilo.join(timeout=0.3)


@dataclass
class Resultado:
    secuencia: int
    capturado: float
    imagen: object
    identidad: object
    detalle: str
    vector: object


class Vision:
    def __init__(self, config, personas):
        self.c = config
        self.motor = MotorRostros(config, personas)
        self.camara = Camara(config["camara"])
        self.stop = threading.Event()
        self.lock = threading.Lock()
        self.ultimo = None
        self.error = None
        self.hilo = threading.Thread(target=self._procesar, daemon=True)
        self.hilo.start()

    def _procesar(self):
        anterior = -1
        try:
            while not self.stop.is_set():
                dato = self.camara.obtener()
                if dato is None or dato[0] == anterior:
                    self.stop.wait(0.02)
                    continue
                secuencia, capturado, frame = dato
                anterior = secuencia
                if time.monotonic() - capturado > self.c["tiempo_maximo_sin_imagen"]:
                    continue
                imagen, identidad, detalle, vector = self.motor.analizar(frame)
                with self.lock:
                    self.ultimo = Resultado(secuencia, capturado, imagen, identidad, detalle, vector)
                self.stop.wait(0.12)
        except Exception as exc:
            self.error = str(exc)

    def obtener(self):
        with self.lock:
            return self.ultimo

    def close(self):
        self.stop.set()
        self.camara.close()
        self.hilo.join(timeout=0.3)
