#!/usr/bin/env python3
"""Ejecutar en el escritorio de la Raspberry Pi, también mediante VNC."""
import argparse
import json
import math
from pathlib import Path
import time
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
from control import Control, Salidas

BASE = Path(__file__).resolve().parent


def configuracion():
    c = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
    pines = [c[k] for k in ("gpio_verde", "gpio_rojo", "gpio_buzzer_simulado")]
    if len(set(pines)) != 3 or any(type(p) is not int or not 2 <= p <= 27 for p in pines):
        raise ValueError("Los tres GPIO deben ser distintos, enteros y estar entre 2 y 27")
    for clave in ("segundos_abierta", "segundos_denegado", "segundos_sin_rostro",
                  "segundos_confirmacion", "tiempo_maximo_sin_imagen"):
        if not isinstance(c[clave], (int, float)) or not math.isfinite(c[clave]) or c[clave] <= 0:
            raise ValueError("Valor inválido en config.json: " + clave)
    if not 0 < c["umbral_similitud"] <= 1 or not 0 <= c["margen_identidades"] <= 1:
        raise ValueError("Umbral o margen de similitud inválido")
    if type(c["lecturas_confirmacion"]) is not int or c["lecturas_confirmacion"] < 2:
        raise ValueError("Se requieren al menos dos lecturas de confirmación")
    if type(c["tamano_minimo_rostro"]) is not int or not 30 <= c["tamano_minimo_rostro"] <= 400:
        raise ValueError("Tamaño mínimo de rostro inválido")
    fuente = c["camara"]
    if not ((type(fuente) is int and fuente >= 0) or
            (isinstance(fuente, str) and fuente.startswith(("http://", "https://", "rtsp://")))):
        raise ValueError('Cámara: usa 0 para USB o una URL de vídeo')
    return c


class Ventana:
    def __init__(self, root, args, config):
        self.root, self.args, self.c = root, args, config
        self.control = Control(config)
        self.salidas = None
        self.vision = None
        self.cerrando = False
        self.inicio = time.monotonic()
        self.ultima_secuencia = -1
        self.muestras = []
        self.ultima_captura = -1
        root.title("Cerradura facial — prueba con LED")
        root.configure(bg="#f0f2f5")
        root.protocol("WM_DELETE_WINDOW", self.cerrar)
        root.bind("<Escape>", lambda e: self.cerrar())
        tk.Label(root, text="Cerradura facial · prototipo", font=("Arial", 18, "bold"),
                 bg="#f0f2f5").pack(pady=8)
        self.estado = tk.Label(root, text="Iniciando...", font=("Arial", 15, "bold"), bg="#f0f2f5")
        self.estado.pack()
        self.detalle = tk.Label(root, text="", wraplength=630, bg="#f0f2f5", font=("Arial", 11))
        self.detalle.pack(pady=5)
        self.imagen = tk.Label(root, bg="#1c2430")
        if args.modo != "leds":
            self.imagen.pack(padx=10, pady=5)
        self.deteccion = tk.Label(root, text="", bg="#f0f2f5", wraplength=630)
        self.deteccion.pack()
        self.lienzo = tk.Canvas(root, width=640, height=80, bg="#f0f2f5", highlightthickness=0)
        self.lienzo.pack()
        self.circulos = []
        for x, texto in ((80, "Verde: apertura"), (300, "Rojo: cierre"), (520, "Amarillo: buzzer")):
            self.circulos.append(self.lienzo.create_oval(x-14, 8, x+14, 36, fill="#b0b0b0", outline=""))
            self.lienzo.create_text(x, 57, text=texto)
        botones = tk.Frame(root, bg="#f0f2f5")
        botones.pack(pady=10)
        if args.modo in ("iniciar", "leds"):
            self.salidas = Salidas(config, args.sin_gpio)
        if args.modo == "leds":
            self.estado.configure(text="Prueba manual del cableado")
            tk.Button(botones, text="Probar autorizado", command=lambda: self.control.activar(
                True, time.monotonic())).pack(side="left", padx=6)
            tk.Button(botones, text="Probar denegado", command=lambda: self.control.activar(
                False, time.monotonic())).pack(side="left", padx=6)
        else:
            from vision import Vision, cargar_rostros
            personas = cargar_rostros()
            if args.modo == "iniciar" and not personas:
                raise ValueError("Primero registra un rostro: python3 app.py registrar Eduardo")
            if args.modo == "registrar":
                if not args.nombre or args.nombre.strip() in ("", "?", "*", "~") or len(args.nombre.strip()) > 50:
                    raise ValueError("Indica un nombre válido: python3 app.py registrar Eduardo")
                if args.nombre.strip() in personas:
                    raise ValueError("Ese nombre ya existe. Usa otro para conservar el registro anterior")
                self.captura = tk.Button(botones, text="Capturar muestra 1/8", command=self.capturar)
                self.captura.pack(side="left", padx=6)
                root.bind("<space>", lambda e: self.capturar())
            self.vision = Vision(config, personas)
        tk.Button(botones, text="Salir (Esc)", command=self.cerrar).pack(side="left", padx=6)
        if args.sin_gpio:
            tk.Label(root, text="SIMULACIÓN: GPIO desactivados", bg="#f0f2f5").pack()
        self.actualizar()

    def capturar(self):
        from vision import guardar_persona
        import numpy as np
        dato = self.vision.obtener() if self.vision else None
        if (dato is None or dato.vector is None or
                time.monotonic() - dato.capturado > self.c["tiempo_maximo_sin_imagen"]):
            self.detalle.configure(text="Necesito un único rostro cercano y una imagen reciente")
            return
        if dato.secuencia == self.ultima_captura:
            return
        if self.muestras and float(np.dot(dato.vector, self.muestras[0])) < 0.45:
            self.detalle.configure(text="Vuelve a mirar de frente; no cambies de persona durante el registro")
            return
        self.muestras.append(dato.vector.copy())
        self.ultima_captura = dato.secuencia
        if len(self.muestras) == 8:
            guardar_persona(self.args.nombre, self.muestras)
            messagebox.showinfo("Registro completado", "Rostro guardado. Ahora ejecuta: python3 app.py iniciar")
            self.cerrar()
            return
        self.captura.configure(text=f"Capturar muestra {len(self.muestras)+1}/8")
        self.detalle.configure(text="Cambia ligeramente el ángulo de la cara y vuelve a capturar")

    def actualizar(self):
        if self.cerrando:
            return
        ahora = time.monotonic()
        dato = self.vision.obtener() if self.vision else None
        if self.vision:
            saludable = (dato is not None and not self.vision.error and
                         ahora - dato.capturado <= self.c["tiempo_maximo_sin_imagen"])
            if self.args.modo == "iniciar":
                if not saludable:
                    if ahora - self.inicio > self.c["tiempo_maximo_sin_imagen"]:
                        self.control.fallo(ahora)
                elif dato.secuencia != self.ultima_secuencia:
                    self.control.observar(dato.identidad, ahora)
            if dato and dato.secuencia != self.ultima_secuencia:
                foto = ImageTk.PhotoImage(Image.fromarray(dato.imagen[:, :, ::-1]))
                self.imagen.configure(image=foto)
                self.imagen.image = foto
                self.ultima_secuencia = dato.secuencia
            self.deteccion.configure(text=(dato.detalle if saludable else
                ("Error: " + self.vision.error if self.vision.error else "Esperando imagen de la cámara...")))
            if self.args.modo == "registrar":
                self.estado.configure(text=f"Registrar: {self.args.nombre} · {len(self.muestras)}/8 muestras")
                self.captura.configure(state="normal" if saludable and dato.vector is not None else "disabled")
            elif self.args.modo == "camara":
                self.estado.configure(text="Prueba de cámara · GPIO desactivados")
        luces = self.control.luces(ahora)
        if self.salidas:
            self.salidas.aplicar(luces)
            self.estado.configure(text={"ABIERTA": "APERTURA SIMULADA", "CERRADA": "PUERTA CERRADA",
                "DENEGADO": "ACCESO DENEGADO", "FALLO": "CERRADA · SIN IMAGEN"}[self.control.estado])
            self.detalle.configure(text=self.control.detalle)
        valores = (luces.verde, luces.rojo, luces.amarillo) if self.salidas else (False, False, False)
        for circulo, valor, color in zip(self.circulos, valores, ("#19a858", "#e34444", "#e0ad00")):
            self.lienzo.itemconfig(circulo, fill=color if valor else "#b0b0b0")
        self.root.after(30, self.actualizar)

    def cerrar(self):
        if self.cerrando:
            return
        self.cerrando = True
        if self.salidas:
            self.salidas.close()
        if self.vision:
            self.vision.close()
        self.root.destroy()


def main():
    parser = argparse.ArgumentParser(description="Cerradura facial con tres LED. Ejecuta dentro de VNC.")
    parser.add_argument("modo", nargs="?", default="iniciar", choices=["leds", "camara", "registrar", "iniciar"])
    parser.add_argument("nombre", nargs="?")
    parser.add_argument("--sin-gpio", action="store_true", help="Simular las salidas solo en pantalla")
    args = parser.parse_args()
    root = None
    ventana = None
    try:
        c = configuracion()
        root = tk.Tk()
        # Conservar el objeto aun si la inicialización falla, para liberar los GPIO.
        ventana = Ventana.__new__(Ventana)
        ventana.salidas = None
        ventana.vision = None
        ventana.cerrando = False
        ventana.root = root
        def error_callback(tipo, valor, traza):
            import traceback
            traceback.print_exception(tipo, valor, traza)
            if ventana.salidas:
                ventana.salidas.close()
            messagebox.showerror("Prueba detenida", str(valor))
            ventana.cerrar()
        root.report_callback_exception = error_callback
        ventana.__init__(root, args, c)
        root.mainloop()
    except KeyboardInterrupt:
        pass
    except Exception as exc:
        print("No se pudo iniciar:", exc)
        if ventana and ventana.salidas:
            ventana.salidas.close()
        if root:
            messagebox.showerror("No se pudo iniciar", str(exc))
        return 1
    finally:
        if ventana and not ventana.cerrando:
            ventana.cerrar()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
