# Cerradura facial — primera prueba con LED

Para Raspberry Pi 4 con Raspberry Pi OS, escritorio accesible por VNC y cámara USB. También admite un teléfono Android con una URL de vídeo local de IP Webcam. No controla todavía un servo ni una cerradura real. El LED amarillo sustituye al buzzer: esta versión no emite sonido.

## Qué hace

| Situación | Verde | Rojo | Amarillo, buzzer simulado |
|---|---|---|---|
| Cerrada, esperando | Apagado | Encendido | Apagado |
| Rostro registrado confirmado | Encendido 5 s | Apagado | Un pulso de 0.2 s |
| Rostro desconocido confirmado | Apagado | Parpadea 2 s y queda encendido | Tres pulsos de 0.2 s |
| Más de un rostro | Apagado | Secuencia de denegado | Tres pulsos |
| Sin rostro o rostro muy pequeño | Apagado, salvo apertura en curso | Conserva el estado correspondiente | Sin nueva señal |
| Cámara/inferencia sin resultado reciente durante más de 2 s | Apagado | Encendido | Apagado |

El sistema exige varias lecturas concordantes antes de decidir. Después de un intento, retírate del encuadre durante dos segundos, con el programa ya cerrado, para permitir otro intento. Una persona que se queda delante no provoca aperturas o alarmas continuas. Una desconexión de cámara también exige retirarse al volver la imagen. Al salir del programa, los tres LED se apagan; las indicaciones de puerta solo son válidas mientras corre esta simulación.

## 1. Cableado

Usa tres LED convencionales (verde, rojo y amarillo), tres resistencias de **330 Ω**, protoboard y cables. Una resistencia independiente por LED.

Apaga la Raspberry desde su escritorio, espera a que termine y desconecta su alimentación antes de cablear.

| LED | GPIO usado en Python (BCM) | Pin físico del conector de 40 pines |
|---|---:|---:|
| Verde | 17 | 11 |
| Rojo | 27 | 13 |
| Amarillo, simulación del buzzer | 22 | 15 |
| Tierra común, GND | — | 6 |

Para cada LED: el GPIO se conecta a su resistencia de 330 Ω; el otro extremo de la resistencia al ánodo (pata larga) del LED. El cátodo (pata corta/lado plano) se conecta al GND común. No conectes estos LED a los pines de 5 V. BCM 17 no es el pin físico 17. Si ya cortaste las patas, guíate por el lado plano del encapsulado. No conectes el buzzer de dos patas ni el servo en esta etapa.

Si necesitas comprobar la orientación del conector, ejecuta `pinout` en la Raspberry; es parte de GPIO Zero. Verifica la posición del pin físico 1 antes de contar.

## 2. Preparar el programa

Descarga y descomprime `cerradura_leds.zip` en **la Raspberry**, usando el navegador dentro de VNC si te resulta más fácil. Mueve la carpeta extraída `cerradura_leds` a tu carpeta personal. En una terminal del escritorio de la Raspberry:

```bash
cd ~/cerradura_leds
bash instalar.sh
```

Se usa Python del sistema (`/usr/bin/python3`) y paquetes de Raspberry Pi OS. No necesitas `pip`, un entorno virtual ni ejecutar el programa como administrador. La instalación requiere Internet y descarga los modelos oficiales (aproximadamente 39 MB), además de las dependencias. Detecta la versión de OpenCV y elige el YuNet compatible. El registro y reconocimiento posteriores son locales y no necesitan Internet. Para VNC sí necesitas conservar la red local, por ejemplo el hotspot del teléfono.

## 3. Comprobar los LED

```bash
python3 app.py leds
```

Se abre una ventana. Al inicio debe estar encendido solo el rojo. Pulsa **Probar autorizado**: verde durante cinco segundos y un destello amarillo corto. Pulsa **Probar denegado**: rojo parpadeando y tres destellos amarillos. Pulsa **Salir** antes del siguiente paso. Ejecuta una sola instancia del proyecto y detén los programas anteriores de Thonny que usen estos GPIO.

## 4. Comprobar la cámara

Conecta tu webcam por USB a la Raspberry. En `config.json`, la configuración inicial es `"camara": 0`.

```bash
python3 app.py camara
```

Debes ver el vídeo y un recuadro alrededor del rostro. Acércate hasta que deje de indicar que estás lejos. Procura iluminación frontal y evita una ventana brillante detrás. Esta prueba no usa GPIO. Cierra su ventana antes de continuar.

Si usas **Android con IP Webcam**, cambia solamente el valor de `camara` por la URL de vídeo que corresponda a tu teléfono, por ejemplo:

```json
"camara": "http://192.168.43.1:8080/video"
```

Esa IP es solo un ejemplo: usa la que muestre la aplicación. El teléfono y la Raspberry deben tener comunicación por la red local; puede ser el hotspot del teléfono. Configura el vídeo del teléfono a 640×480 para empezar y mantenlo activo. La URL debe entregar vídeo, no la página de controles. No publiques el stream en Internet.

## 5. Registrar tu rostro

```bash
python3 app.py registrar Eduardo
```

Debe aparecer solamente tu cara. Pulsa **Capturar muestra** ocho veces (o la barra espaciadora). Empieza de frente y cambia ligeramente la orientación entre capturas: un poco a izquierda, derecha, arriba y abajo, manteniendo la cara visible. No cambies de persona durante este registro.

Al terminar aparece una confirmación y se guarda `rostros.json` en la carpeta del proyecto. Contiene nombres y descriptores numéricos, no fotografías. El proyecto no envía esos datos a un servicio externo. Para otra persona, repite el comando cambiando el nombre; usa comillas si contiene espacios. La autorización es para esa persona: no registres al participante que usarás para probar la denegación.

Para empezar todo el registro de cero, cierra el programa y renombra `rostros.json` como `rostros_respaldo.json`; después registra de nuevo. No se sobrescribe automáticamente un nombre existente.

## 6. Activar reconocimiento y salidas

```bash
python3 app.py iniciar
```

Mira a la cámara aproximadamente un segundo: la secuencia requiere al menos cuatro resultados concordantes durante 0.8 s. Una vez que regrese al rojo fijo, sal del encuadre dos segundos para repetir. Prueba después con alguien que no hayas registrado. También prueba desconectar la cámara: tras superar dos segundos sin imagen procesada reciente, queda rojo fijo y el verde se apaga.

Para terminar pulsa **Salir** o **Esc**. Para probar solo la pantalla, sin conectar GPIO, agrega `--sin-gpio` al comando. No hace falta mantener abierto Thonny; todo se ejecuta desde la terminal de la Raspberry dentro de VNC.

## Ajustes y problemas frecuentes

- **No aparece imagen:** cierra otras aplicaciones que usen la cámara; para USB prueba `"camara": 1` o revisa `ls /dev/video*`. No todos los nodos `/dev/video*` de una webcam producen vídeo. Para teléfono revisa su IP actual y el stream.
- **`No module named cv2/gpiozero/PIL`:** ejecuta la instalación y usa `/usr/bin/python3 app.py iniciar`. Un entorno virtual o un intérprete distinto de Thonny puede ocultar los paquetes del sistema.
- **Sin ventana / error DISPLAY:** ejecuta desde una terminal abierta en el escritorio VNC de la Raspberry, no desde una sesión SSH sin escritorio.
- **Pin ocupado:** detén el código anterior en Thonny y cierra otras instancias. No ejecutes las pruebas simultáneamente.
- **No me reconoce:** mejora iluminación, mira de frente y vuelve a registrar con pequeñas variaciones. El umbral inicial `umbral_similitud: 0.5` es un punto de partida; una similitud no es un porcentaje de confianza. Un umbral más alto exige mayor coincidencia. No lo reduzcas para lograr que abra sin volver a evaluar personas no registradas.
- **Retraso o “sin imagen” al usar teléfono:** empieza con 640×480 y comprueba la conexión local. El mecanismo comprueba la llegada de fotogramas; no puede detectar todos los casos en que una fuente retransmite imágenes antiguas.
- **Cambiar tiempos/pines:** edita `config.json` con el programa detenido y vuelve a ejecutarlo. `gpio_buzzer_simulado` sigue siendo un LED, no una autorización para conectar un buzzer cualquiera directamente.

## Alcance de la prueba

Esto es un **prototipo**, sin detección de vida: una fotografía o vídeo podría engañarlo. No debe ser el único mecanismo de una cerradura real. La ventana indica una orden simulada de apertura, no mide la posición física de una puerta. La respuesta ante cámara desconectada depende de que el programa y el sistema operativo sigan funcionando; no es una protección de hardware.

Se ejecutaron correctamente 12 pruebas automáticas del controlador (`python3 -m unittest -v test_control.py`). También se comprobó el motor con OpenCV 4.6 y 4.12 usando imágenes de prueba: detección, comparación coincidente, rechazo de una imagen distinta y ausencia de rostro. Se comprobó guardar y volver a leer un registro con OpenCV 4.12. Estas comprobaciones no miden la tasa de acierto real ni sustituyen las pruebas con tu cámara. La ventana, instalación, cámara, GPIO y rendimiento deben comprobarse en tu Raspberry; no se han probado físicamente en ella.

## Archivos y fuentes

- `app.py`: ventana y comandos para cableado, cámara, registro y funcionamiento.
- `control.py`: secuencias y temporizadores de salidas.
- `vision.py`: cámara, detección YuNet y comparación SFace.
- `descargar_modelos.py`: descarga modelos oficiales con comprobación SHA-256.
- `config.json`: pines, cámara, tiempos y parámetros.
- `instalar.sh`: dependencias de Raspberry Pi OS y modelos.

Referencias técnicas: [OpenCV, detección y reconocimiento facial](https://docs.opencv.org/4.x/d0/dd4/tutorial_dnn_face.html), [OpenCV Zoo](https://github.com/opencv/opencv_zoo), [GPIO Zero, LED y numeración BCM](https://gpiozero.readthedocs.io/en/stable/recipes.html). Los modelos se descargan del repositorio oficial de OpenCV; conserva sus términos de licencia si los redistribuyes. No van incluidos en el ZIP.
